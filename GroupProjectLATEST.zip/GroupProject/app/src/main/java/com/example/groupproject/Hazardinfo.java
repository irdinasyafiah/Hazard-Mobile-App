package com.example.groupproject;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Hazardinfo {

    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("hname")
    @Expose
    public String hname;
    @SerializedName("loc")
    @Expose
    public String loc;
    @SerializedName("dsc")
    @Expose
    public String dsc;
    @SerializedName("lat")
    @Expose
    public String lat;
    @SerializedName("lng")
    @Expose
    public String lng;

}